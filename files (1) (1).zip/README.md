# 🔍 Blone Scanner

Blone Scanner is a fast and lightweight web scanner for Termux with a modular design and Telegram integration.

## 📱 Quick Installation

```bash
curl -sSL https://raw.githubusercontent.com/Souliifar/blone/main/install | bash
```

## 🚀 Features

- Multiple scanning modes
- User-friendly interface
- Customizable settings
- Multi-threaded scanning
- Modular design for extensions
- Telegram integration

## 📚 Usage

1. Start the scanner:
```bash
mscan
```

2. Select a mode:
- Manual File Scan
- Auto Scan Folder
- Manual Input Scan

3. Follow on-screen instructions to configure and run your scan.

## 📂 Directories

- Scans: `~/storage/shared/download/scans`
- Results: `~/storage/shared/download/results`
- Modules: `~/storage/shared/download/modules`
- Config: `~/storage/shared/download/config`

## 📦 Modules

Create and share custom modules by placing them in the `modules` directory.

## 🔄 Updates

Use the built-in updater to keep the tool and modules up-to-date.

## 📞 Support

- Telegram: [@MeQhe](https://t.me/MeQhe)
- Issues: [GitHub Issues](https://github.com/Souliifar/blone/issues)

## 📜 License

MIT License - Feel free to modify and share!