import os
import sys
import json
import subprocess
from datetime import datetime
from colorama import Fore

class Utils:
    @staticmethod
    def setup_directories():
        dirs = {
            'scans': os.path.expanduser("~/storage/shared/download/scans"),
            'results': os.path.expanduser("~/storage/shared/download/results"),
            'modules': os.path.expanduser("~/storage/shared/download/modules"),
            'config': os.path.expanduser("~/storage/shared/download/config")
        }
        
        for dir_name, dir_path in dirs.items():
            os.makedirs(dir_path, exist_ok=True)
        return dirs

    @staticmethod
    def get_modules_path():
        return os.path.expanduser("~/storage/shared/download/modules")

    @staticmethod
    def load_module(module_name):
        module_path = os.path.join(Utils.get_modules_path(), module_name)
        if not os.path.exists(module_path):
            return None
            
        try:
            sys.path.insert(0, module_path)
            module = __import__('module')
            sys.path.pop(0)
            return module
        except:
            return None

    @staticmethod
    def install_requirements(requirements):
        try:
            for package in requirements:
                subprocess.check_call([
                    sys.executable,
                    "-m",
                    "pip",
                    "install",
                    package,
                    "--quiet"
                ])
            return True
        except:
            return False