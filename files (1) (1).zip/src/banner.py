#!/data/data/com.termux/files/usr/bin/python3
from colorama import Fore, Style
from datetime import datetime

class Banner:
    @staticmethod
    def show():
        print(f"""{Fore.CYAN}
     ▄▄▄▄    ██▓     ▒█████   ███▄    █ ▓█████ 
    ▓█████▄ ▓██▒    ▒██▒  ██▒ ██ ▀█   █ ▓█   ▀ 
    ▒██▒ ▄██▒██░    ▒██░  ██▒▓██  ▀█ ██▒▒███   
    ▒██░█▀  ▒██░    ▒██   ██░▓██▒  ▐▌██▒▒▓█  ▄ 
    ░▓█  ▀█▓░██████▒░ ████▓▒░▒██░   ▓██░░▒████▒
    ░▒▓███▀▒░ ▒░▓  ░░ ▒░▒░▒░ ░ ▒░   ▒ ▒ ░░ ▒░ ░
    ▒░▒   ░ ░ ░ ▒  ░  ░ ▒ ▒░ ░ ░░   ░ ▒░ ░ ░  ░
     ░    ░   ░ ░   ░ ░ ░ ▒     ░   ░ ░    ░   
     ░          ░  ░    ░ ░           ░    ░  ░
          ░                                     
        {Style.RESET_ALL}""")
        print(f"{Fore.YELLOW}          Souliifar - @MeQhe")
        print(f"{Fore.CYAN}📅 {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC")
        print(f"🔄 Version: 1.0.0\n")

    @staticmethod
    def show_menu():
        print(f"{Fore.CYAN}🔹 Select Mode:")
        print("  1. Manual File Scan")
        print("  2. Auto Scan Folder")
        print("  3. Manual Input Scan")
        print("  4. Edit Settings")
        print("  5. Update Tool")
        print("  6. Exit\n")