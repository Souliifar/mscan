import os
import sys
import threading
import requests
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from colorama import init, Fore
from .banner import Banner
from .config import Config
from .utils import Utils

init(autoreset=True)

class Scanner:
    def __init__(self):
        self.settings = Config.load_settings()
        self.results = []
        self.lock = threading.Lock()
        self.dirs = Utils.setup_directories()
        
    def scan_target(self, target, port):
        try:
            url = f"http://{target}:{port}"
            response = requests.get(
                url,
                timeout=self.settings['timeout'],
                headers={'User-Agent': self.settings['user_agent']},
                allow_redirects=self.settings['allow_redirects']
            )
            
            if response.status_code == 200:
                with self.lock:
                    result = {
                        'url': url,
                        'status': response.status_code,
                        'server': response.headers.get('Server', 'Unknown'),
                        'content_type': response.headers.get('Content-Type', 'Unknown'),
                        'timestamp': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
                    }
                    self.results.append(result)
                    print(f"{Fore.GREEN}[+] Found: {url} ({result['server']})")
        except:
            pass

    def scan_from_file(self, file_path):
        try:
            with open(file_path) as f:
                targets = [line.strip() for line in f if line.strip()]
        except:
            print(f"{Fore.RED}[!] Error reading file")
            return

        self.start_scan(targets)

    def scan_single(self, target):
        self.start_scan([target])

    def start_scan(self, targets):
        print(f"\n{Fore.CYAN}[*] Starting scan of {len(targets)} targets...")
        print(f"[*] Using {self.settings['threads']} threads")

        with ThreadPoolExecutor(max_workers=self.settings['threads']) as executor:
            futures = []
            for target in targets:
                for port in self.settings['ports']:
                    futures.append(
                        executor.submit(self.scan_target, target, port)
                    )

        if self.results:
            self.save_results()

    def save_results(self):
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        filename = f"scan_results_{timestamp}.json"
        filepath = os.path.join(self.dirs['results'], filename)

        try:
            with open(filepath, 'w') as f:
                json.dump({
                    'scan_date': timestamp,
                    'settings': self.settings,
                    'results': self.results
                }, f, indent=4)
            print(f"\n{Fore.GREEN}[+] Results saved to: {filename}")
        except:
            print(f"\n{Fore.RED}[!] Error saving results")

    def run(self):
        try:
            while True:
                Banner.show()
                Banner.show_menu()
                
                choice = input(f"{Fore.YELLOW}Choice: {Fore.RESET}")

                if choice == '1':
                    file_path = input("\nEnter file path: ")
                    self.scan_from_file(file_path)

                elif choice == '2':
                    print(f"\n{Fore.CYAN}[*] Monitoring: {self.dirs['scans']}")
                    # Implement auto-scan functionality

                elif choice == '3':
                    target = input("\nEnter target: ")
                    self.scan_single(target)

                elif choice == '4':
                    # Implement settings editor
                    pass

                elif choice == '5':
                    # Implement update functionality
                    pass

                elif choice == '6':
                    print(f"\n{Fore.YELLOW}[!] Exiting...")
                    break

                input(f"\n{Fore.YELLOW}Press Enter to continue...")
                os.system('clear')

        except KeyboardInterrupt:
            print(f"\n{Fore.YELLOW}[!] Exiting...")

def main():
    scanner = Scanner()
    scanner.run()

if __name__ == "__main__":
    main()