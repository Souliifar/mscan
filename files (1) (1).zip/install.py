#!/data/data/com.termux/files/usr/bin/python
import os
import sys
import json
import subprocess
from datetime import datetime

class Installer:
    def __init__(self):
        self.home = os.path.expanduser("~")
        self.tool_dir = os.path.join(self.home, "blone")
        self.download_dir = os.path.join(self.home, "storage/shared/download")
        self.start_time = datetime.now()

    def print_banner(self):
        print(f"""
🔧 Blone Scanner Python Setup
📅 {self.start_time.strftime('%Y-%m-%d %H:%M:%S')}
👤 User: {os.getenv('USER', 'unknown')}
        """)

    def install_python_packages(self):
        packages = [
            "requests>=2.31.0",
            "colorama>=0.4.6",
            "tqdm>=4.66.1",
            "python-telegram-bot>=20.7",
            "beautifulsoup4>=4.12.0",
            "lxml>=4.9.3"
        ]
        
        for package in packages:
            try:
                subprocess.check_call([
                    sys.executable,
                    "-m",
                    "pip",
                    "install",
                    package,
                    "--quiet"
                ])
                print(f"✅ Installed: {package}")
            except:
                print(f"❌ Failed to install: {package}")
                return False
        return True

    def create_config(self):
        config = {
            'version': '1.0.0',
            'threads': 50,
            'timeout': 5,
            'ports': ['80', '443'],
            'method': 'GET',
            'allow_redirects': True,
            'user_agent': 'BloneScanner/1.0',
            'telegram_token': '',
            'telegram_chat_id': '',
            'auto_update': True
        }
        
        config_path = os.path.join(self.download_dir, "config/settings.json")
        try:
            with open(config_path, 'w') as f:
                json.dump(config, f, indent=4)
            print("✅ Created configuration")
            return True
        except:
            print("❌ Failed to create configuration")
            return False

    def create_launcher(self):
        launcher = "/data/data/com.termux/files/usr/bin/mscan"
        content = f"""#!/data/data/com.termux/files/usr/bin/python
import os
import sys
sys.path.insert(0, "{self.tool_dir}")
from src.scanner import main
if __name__ == "__main__":
    main()
"""
        try:
            with open(launcher, 'w') as f:
                f.write(content)
            os.chmod(launcher, 0o755)
            print("✅ Created launcher")
            return True
        except:
            print("❌ Failed to create launcher")
            return False

    def setup(self):
        self.print_banner()
        
        steps = [
            ("Installing Python packages", self.install_python_packages),
            ("Creating configuration", self.create_config),
            ("Creating launcher", self.create_launcher)
        ]
        
        for step_name, step_func in steps:
            print(f"\n⏳ {step_name}...")
            if not step_func():
                print(f"\n❌ Setup failed at: {step_name}")
                return False
        
        end_time = datetime.now()
        duration = (end_time - self.start_time).seconds
        
        print(f"""
✨ Python setup completed in {duration}s!
📁 Config location: {os.path.join(self.download_dir, "config/settings.json")}
""")
        return True

if __name__ == "__main__":
    installer = Installer()
    installer.setup()