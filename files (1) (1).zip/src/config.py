import os
import json

class Config:
    HOME = os.path.expanduser("~")
    BASE_DIR = os.path.join(HOME, "blone-scanner")
    DOWNLOAD_DIR = os.path.join(HOME, "storage/shared/download")

    SCAN_DIR = os.path.join(DOWNLOAD_DIR, "scans")
    RESULTS_DIR = os.path.join(DOWNLOAD_DIR, "results")
    MODULES_DIR = os.path.join(DOWNLOAD_DIR, "modules")
    CONFIG_DIR = os.path.join(DOWNLOAD_DIR, "config")

    DEFAULT_SETTINGS = {
        'version': '1.0.0',
        'threads': 50,
        'timeout': 5,
        'ports': ['80', '443'],
        'method': 'GET',
        'allow_redirects': True,
        'user_agent': 'BloneScanner/1.0'
    }

    @classmethod
    def setup(cls):
        for directory in [cls.SCAN_DIR, cls.RESULTS_DIR, cls.MODULES_DIR, cls.CONFIG_DIR]:
            os.makedirs(directory, exist_ok=True)

    @classmethod
    def load_settings(cls):
        config_file = os.path.join(cls.CONFIG_DIR, "settings.json")
        try:
            if os.path.exists(config_file):
                with open(config_file) as f:
                    return {**cls.DEFAULT_SETTINGS, **json.load(f)}
            return cls.DEFAULT_SETTINGS
        except:
            return cls.DEFAULT_SETTINGS

    @classmethod
    def save_settings(cls, settings):
        config_file = os.path.join(cls.CONFIG_DIR, "settings.json")
        try:
            with open(config_file, 'w') as f:
                json.dump(settings, f, indent=4)
            return True
        except:
            return False